import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-kot',
  templateUrl: './admin-kot.page.html',
  styleUrls: ['./admin-kot.page.scss'],
})
export class AdminKotPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
