import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-draft',
  templateUrl: './staff-draft.page.html',
  styleUrls: ['./staff-draft.page.scss'],
})
export class StaffDraftPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
