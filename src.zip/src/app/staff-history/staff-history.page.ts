import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-history',
  templateUrl: './staff-history.page.html',
  styleUrls: ['./staff-history.page.scss'],
})
export class StaffHistoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
