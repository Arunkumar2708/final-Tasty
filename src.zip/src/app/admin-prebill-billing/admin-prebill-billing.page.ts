import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-prebill-billing',
  templateUrl: './admin-prebill-billing.page.html',
  styleUrls: ['./admin-prebill-billing.page.scss'],
})
export class AdminPrebillBillingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
