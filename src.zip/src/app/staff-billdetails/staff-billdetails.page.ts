import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-billdetails',
  templateUrl: './staff-billdetails.page.html',
  styleUrls: ['./staff-billdetails.page.scss'],
})
export class StaffBilldetailsPage  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
