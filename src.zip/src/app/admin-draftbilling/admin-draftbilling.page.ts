import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-draftbilling',
  templateUrl: './admin-draftbilling.page.html',
  styleUrls: ['./admin-draftbilling.page.scss'],
})
export class AdminDraftbillingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
