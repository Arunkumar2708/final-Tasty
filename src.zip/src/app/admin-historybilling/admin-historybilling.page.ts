import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-historybilling',
  templateUrl: './admin-historybilling.page.html',
  styleUrls: ['./admin-historybilling.page.scss'],
})
export class AdminHistorybillingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
