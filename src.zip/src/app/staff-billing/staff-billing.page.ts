import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-billing',
  templateUrl: './staff-billing.page.html',
  styleUrls: ['./staff-billing.page.scss'],
})
export class StaffBillingPage  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
